# -*- coding: utf-8 -*-
"""
Use behave4cmd0 step library (predecessor of behave4cmd).
"""

# -- REGISTER-STEPS:
import behave4cmd0.__all_steps__
